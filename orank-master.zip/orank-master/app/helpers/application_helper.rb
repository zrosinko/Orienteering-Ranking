# Base application helpers
module ApplicationHelper
end
