# Admin controller helpers
module AdminHelper
end
