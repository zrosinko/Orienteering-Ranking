# Runner - individual runner record
class Runner < ActiveRecord::Base
end
