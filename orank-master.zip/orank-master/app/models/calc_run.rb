# Calc run table - includes one entry for each time the ranking calculation is run.
class CalcRun < ActiveRecord::Base
end
